/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.citasmedicas1;

/**
 *
 * @author javie
 */
public class CitasMedicas1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
